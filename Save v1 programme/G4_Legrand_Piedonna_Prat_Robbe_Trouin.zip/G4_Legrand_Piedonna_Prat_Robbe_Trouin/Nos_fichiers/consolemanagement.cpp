#include "Nos_fichiers/jeu.h"
#include <limits>

void Couleur (const string & coul)
{
    cout << "\033[7;" << coul <<"m";
} // Couleur()

void ClearBuf ()
{
    cin.clear ();
    cin.ignore (numeric_limits<streamsize>::max(), '\n');

}// ClearBuf ()
