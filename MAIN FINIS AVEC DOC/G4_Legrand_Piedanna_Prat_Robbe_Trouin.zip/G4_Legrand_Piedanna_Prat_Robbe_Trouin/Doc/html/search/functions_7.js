var searchData=
[
  ['jeu',['jeu',['../jeu_8cpp.html#afdf33ef6507a8d51e0ab5210ce727466',1,'jeu():&#160;jeu.cpp'],['../jeu_8h.html#afdf33ef6507a8d51e0ab5210ce727466',1,'jeu():&#160;jeu.cpp']]],
  ['jouer',['Jouer',['../menu_8cpp.html#a900d6cc2e02bd2823dcc739be3ea2713',1,'Jouer(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp'],['../menu_8h.html#a900d6cc2e02bd2823dcc739be3ea2713',1,'Jouer(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp']]]
];
