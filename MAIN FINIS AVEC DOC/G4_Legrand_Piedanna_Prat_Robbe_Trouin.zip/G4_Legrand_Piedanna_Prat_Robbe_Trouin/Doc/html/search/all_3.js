var searchData=
[
  ['fiveincolumn',['FiveInColumn',['../gridmanage_8cpp.html#a9a5e8513bae340487c959c25e03eded6',1,'FiveInColumn(CMat &amp;Grid, const CPosition &amp;Pos, unsigned Howmany):&#160;gridmanage.cpp'],['../gridmanage_8h.html#a9a5e8513bae340487c959c25e03eded6',1,'FiveInColumn(CMat &amp;Grid, const CPosition &amp;Pos, unsigned Howmany):&#160;gridmanage.cpp']]],
  ['fiveinrow',['FiveInRow',['../gridmanage_8cpp.html#a9ed5bb211a261865917a26396d408a09',1,'FiveInRow(CMat &amp;Grid, const CPosition &amp;Pos, unsigned Howmany):&#160;gridmanage.cpp'],['../gridmanage_8h.html#a9ed5bb211a261865917a26396d408a09',1,'FiveInRow(CMat &amp;Grid, const CPosition &amp;Pos, unsigned Howmany):&#160;gridmanage.cpp']]]
];
