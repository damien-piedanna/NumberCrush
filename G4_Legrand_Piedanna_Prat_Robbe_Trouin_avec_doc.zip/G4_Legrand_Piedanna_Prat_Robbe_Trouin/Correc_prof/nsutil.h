#ifndef NSUTIL_H
#define NSUTIL_H

unsigned Rand ();

#endif // NSUTIL_H
