#include <iostream>

#include "game.h"
#include "Correc_prof/params.h"
#include "Correc_prof/gridmanagement.h"
#include "Nos_fichiers/jeu.h"
#include <map>

using namespace std;

unsigned ComputeScore (unsigned Score)
{
    return Score * (Score + 1) / 2;
}
