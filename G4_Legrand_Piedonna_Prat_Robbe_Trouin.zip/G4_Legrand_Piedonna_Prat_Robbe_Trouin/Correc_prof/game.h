#ifndef GAME_H
#define GAME_H

#include "Correc_prof/type.h"

unsigned ComputeScore (unsigned Score);

#endif // GAME_H
