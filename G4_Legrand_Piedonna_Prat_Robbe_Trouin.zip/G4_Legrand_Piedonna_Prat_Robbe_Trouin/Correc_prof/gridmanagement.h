#ifndef GRIDMANAGEMENT_H
#define GRIDMANAGEMENT_H

#include <string>

#include "Correc_prof/type.h" //nos types
#include "Correc_prof/nsutil.h"

void ClearScreen ();

void Color (const std::string & Col);

#endif // GRIDMANAGEMENT_H
