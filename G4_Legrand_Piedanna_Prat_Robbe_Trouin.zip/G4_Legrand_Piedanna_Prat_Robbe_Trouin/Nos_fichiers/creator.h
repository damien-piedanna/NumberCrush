#ifndef CREATOR_H
#define CREATOR_H

#include <string>
#include <vector>

using namespace std;

void DisplayGridCreator(unsigned & i, vector <string> & StockDeVar, unsigned & GridSize);

bool TestValeurDansString(string & Str, unsigned & GridSize);

string UserImputNomLevel();

unsigned UserImputTailleGrille();

unsigned UserImputScoreToWin();

unsigned UserImputNbCandies();

unsigned UserImputCoups();

vector <string> UserImputNiveau(vector <string> & StockDeVar, unsigned & GridSize);

void LevelCreator();

#endif // CREATOR_H
