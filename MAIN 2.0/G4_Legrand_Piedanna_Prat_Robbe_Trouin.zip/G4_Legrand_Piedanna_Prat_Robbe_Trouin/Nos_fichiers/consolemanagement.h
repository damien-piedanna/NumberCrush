#ifndef CONSOLEMANAGEMENT_H
#define CONSOLEMANAGEMENT_H

#include <Nos_fichiers/jeu.h>

/*!
 * \brief Couleur permet d'afficher des couleurs sur la console
 * \param coul[in] couleur a afficher
 */

void Couleur (const string & coul); //Permet d'afficher des couleurs sur la console

/*!
 * \brief ClearBuf vide le tampon de cin
 */
void ClearBuf ();                   //Vide le tampon de cin

/*!
 * \brief Pause permet de mettre une pause d'affichage
 * \param secondes temps de la pause (en sec)
 */
void Pause (float secondes);        //Permet de faire une pause (en sec)

#endif // CONSOLEMANAGEMENT_H
