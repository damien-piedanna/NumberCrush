#ifndef GRIDMANAGE_H
#define GRIDMANAGE_H
#include "Nos_fichiers/jeu.h"


void InitGrid (CMat & Grid, unsigned Size, unsigned NbCandies);                         //Initialise la grille avec une taille de Size et avec NbCandies max.

bool AtLeastThreeInAColumn  (const CMat & Grid, CPosition & Pos, unsigned & Howmany);   //Permet de trouver une combinaison de Howmany en colonnes
bool AtLeastThreeInARow  (const CMat & Grid, CPosition & Pos, unsigned & Howmany);      //Permet de trouver une combinaison de Howmany en lignes
void RemovalInColumn (CMat & Grid, const CPosition & Pos, unsigned  Howmany);           //Remplace les combinaisons trouvé en colonne par des 0
void RemovalInRow (CMat & Grid, const CPosition & Pos, unsigned  Howmany);              //Remplace les combinaisons trouvé en ligne par des 0
void FiveInColumn (CMat & Grid, const CPosition & Pos, unsigned  Howmany);              //Place le bonus "boule spéciale" en colonne
void FiveInRow (CMat & Grid, const CPosition & Pos, unsigned  Howmany);                 //Place le bonus "boule spéciale" en ligne

#endif // GRIDMANAGE_H
