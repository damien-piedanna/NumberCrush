#ifndef MENU_H
#define MENU_H

#include <Nos_fichiers/jeu.h>

void DisplayFile (const string & File);                                                                         //Affiche un fichier
void Jouer (CMat & Grid, unsigned & Size, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);          //Menu pour choisir son mode de jeu
void Classique (CMat & Grid, unsigned & Size, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);      //Mode de jeu classique, 3 Levelx de difficultés.
void Perso(CMat & Grid, unsigned & Size, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);                              //Mode de jeu personnalisé, le joueur peut choisir les options de la partie.
void Histoire(CMat & Grid, unsigned & Size, unsigned & NbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);        //Mode histoire avec Level
void Menu2 (CMat & Grid, unsigned & Size, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);           //Menu principal
void RetrieveDataLevel(const string & NameLevel, vector <vector <unsigned>> & Grid, unsigned  & NbCandies, unsigned & Coup, unsigned & ScoreToWin);
void LoadLevel (const string & NameLevel, CMat & Grid, unsigned & NbCandies, unsigned & Coup, unsigned & Size, unsigned & ScoreToWin);
void RetourMenu (CMat & Grid, unsigned & Size, unsigned & NbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void MenuScore(CMat & Grid, unsigned & Size, unsigned & NbCandies, unsigned & Coup, string & LvlScores);

#endif // MENU_H
