var searchData=
[
  ['histoire',['Histoire',['../menu_8cpp.html#ad4e01eee673977bd1ead5aa2ad964c3d',1,'Histoire(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp'],['../menu_8h.html#ad4e01eee673977bd1ead5aa2ad964c3d',1,'Histoire(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp']]]
];
