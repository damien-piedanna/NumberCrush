#ifndef CONSOLEMANAGEMENT_H
#define CONSOLEMANAGEMENT_H

#include <Nos_fichiers/jeu.h>

void Couleur (const string & coul);   //Permet d'afficher des couleurs sur la console
void ClearBuf ();                     //Vide le tampon de cin
void Pause (float secondes);          //Fait une pause en secondes (pour l'affichage)

#endif // CONSOLEMANAGEMENT_H
