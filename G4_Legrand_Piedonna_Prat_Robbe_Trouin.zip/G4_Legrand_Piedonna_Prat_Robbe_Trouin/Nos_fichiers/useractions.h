#ifndef USERACTIONS_H
#define USERACTIONS_H

#include <Nos_fichiers/jeu.h>

using namespace std;

unsigned GetUnsigned (unsigned min, unsigned max);  //Recupération d'un unsigned
CPosition GetPos (CPosition & Pos, unsigned Size);  //Récupération positions
char GetDirection (char Direction);                 //Récupération direction

#endif // USERACTIONS_H
