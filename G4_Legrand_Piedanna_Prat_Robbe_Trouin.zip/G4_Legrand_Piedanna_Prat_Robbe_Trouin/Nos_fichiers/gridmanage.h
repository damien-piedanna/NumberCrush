#ifndef GRIDMANAGE_H
#define GRIDMANAGE_H
#include "Nos_fichiers/jeu.h"

void InitGrid2 (CMat & Grid, unsigned Size_col, unsigned Size_lin, unsigned NbCandies);                                     //Initialise la grille sans combinaison

bool AtLeastThreeInAColumn2  (const CMat & Grid, CPosition & Pos, unsigned & Howmany, bool init);    //Permet de trouver une combinaison de Howmany en colonnes
bool AtLeastThreeInARow2  (const CMat & Grid, CPosition & Pos, unsigned & Howmany, bool init);       //Permet de trouver une combinaison de Howmany en lignes

void RemovalInColumn2 (CMat & Grid, const CPosition & Pos, unsigned  Howmany);                      //Remplace les combinaisons en colonne par des 0
void RemovalInRow2 (CMat & Grid, const CPosition & Pos, unsigned  Howmany);                         //Remplace les combinaisons en ligne par des 0

void FiveInColumn (CMat & Grid, const CPosition & Pos, unsigned  Howmany);
void FiveInRow (CMat & Grid, const CPosition & Pos, unsigned  Howmany);

#endif // GRIDMANAGE_H
