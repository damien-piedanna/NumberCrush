#include "jeu.h"
#include "Correc_prof/gridmanagement.h"
#include "gridmanage.h"
#include "consolemanagement.h"
#include <unistd.h>
#include "Nos_fichiers/params2.h"



void ClearAssociation (CMat & Grid, unsigned NbCandies)
{
    CPosition Pos;
    unsigned Howmany;
    do
    {
        while (AtLeastThreeInAColumn (Grid, Pos, Howmany))
        {
            RemovalInColumn (Grid, Pos, Howmany);
        }
        while (AtLeastThreeInARow  (Grid, Pos, Howmany))
        {
            RemovalInRow (Grid, Pos, Howmany);
        }
    } while (ReplaceEmpty(Grid, NbCandies));
}

bool ReplaceEmpty (CMat & Grid, unsigned NbCandies)
{
    srand(time(NULL));
    bool check = false;
    for (unsigned i (0); i < Grid.size(); ++i)
    {
        for (unsigned j(0); j < Grid[i].size(); ++j)
        {
            if (Grid [i][j] == 0)
            {
                Grid [i][j] = rand()%NbCandies+1;
                //cout << "remplacement de la case" << i+1 << j+1 << endl;
                check = true;
            }

        }
    }
    return check;
} // ReplaceEmpty ()

void DisplayGrid (const CMat & Grid)
{
    ClearScreen ();
    Couleur(CReset);
    unsigned line = 1;
    unsigned columns = 1;
    cout << "  ";
    while (columns <= Grid.size())
    {
        cout << columns;
        if (columns <= 9)
            cout << ' ';
        ++columns;
    }
    columns=1;
    cout << endl;
    for (unsigned i (0); i < Grid.size(); ++i)
    {
        Couleur(CReset);
        cout << line;
        if (line <= 9)
            cout << ' ';

        for (unsigned j(0); j < Grid[i].size(); ++j)
        {
            DisplayCouleur(Grid[i][j]);
            if (Grid [i][j] == 0) //cases vides
            {
                Couleur(CReset);
                cout << "  ";
            }
            if (Grid [i][j] == 11) //boules spéciales
            {
                Couleur(CReset);
                cout << "()";
            }
            if (Grid [i][j] == 12) //Mur
            {
                DisplayCouleur(12);
                cout << "  ";
            }
            if (Grid [i][j] <= 9 && Grid [i][j] != 0)
                cout << Grid [i][j] << ' ';
        }
        Couleur(CReset);
        if (line <= 9)
            cout << ' ';
        cout << line;
         ++line;
        cout << endl;

    }
    Couleur(CReset);
    cout << "  ";
    while (columns <= Grid.size())
    {
        cout << columns;
        if (columns <= 9)
            cout << ' ';
        ++columns;
    }
    cout << endl << endl;
} // DisplayGrid ()

void DownGrid (CMat & Grid)
{
    for (unsigned i (0); i < Grid.size(); ++i)
    {
        for (unsigned j(0); j < Grid[i].size(); ++j)
        {
            unsigned ibis = i;
            if (Grid [i][j] == 0)
            {
                while (ibis > 0)
                {
                    swap (Grid[ibis-1][j], Grid[ibis][j]);
                    //cout << "echange de la case" << j+1 << ibis+1 << " avec " <<  j+1 << ibis << endl;
                    ibis--;
                }
            }
        }
    }
} //DownGrid ()

void MakeAMove (CMat & Grid, unsigned & Score)
{
    bool check = false;
    CPosition Pos;
    CPosition PosToMove;
    unsigned Size;
    char Direction;
    Size = Grid.size();
    while (true)
    {
        Pos = GetPos (Pos, Size); //Récupération position
        cout << endl;
        Direction = GetDirection (Direction); //Récupération direction
        switch (Direction)
        {
            case MoveUp :
                if(Pos.first != 0)
                {
                   check = true;
                   PosToMove.first = Pos.first-1;
                   PosToMove.second = Pos.second;
                   Move (Grid, Score, Pos, PosToMove);
                }
            break;
            case MoveDown :
                if(Pos.first != Grid.size()-1)
                {
                   check = true;
                   PosToMove.first = Pos.first+1;
                   PosToMove.second = Pos.second;
                   Move (Grid, Score, Pos, PosToMove);
                }

            break;
            case MoveRight :
                if(Pos.second != Grid.size()-1)
                {
                   check = true;
                   PosToMove.first = Pos.first;
                   PosToMove.second = Pos.second+1;
                   Move (Grid, Score, Pos, PosToMove);
                }
            break;
            case MoveLeft :
                if(Pos.second != 0)
                {
                   check = true;
                   PosToMove.first = Pos.first;
                   PosToMove.second = Pos.second-1;
                   Move (Grid, Score, Pos, PosToMove);
                }
            break;
        }
        ClearBuf();
        if (check) break;
        cout << "Vous ne pouvez pas déplacer un mur." << endl
             << "Vous ne pouvez pas déplacer une case hors de la grille." << endl;
    }
} //MakeAMove()

void Move (CMat & Grid, unsigned & Score, const CPosition & Pos, const CPosition & PosToMove)
{
    if((Grid[PosToMove.first][PosToMove.second] != 0) && (Grid[Pos.first][Pos.second] != 0) //On ne bouge pas un 0
    && (Grid[PosToMove.first][PosToMove.second] != 12) && (Grid[Pos.first][Pos.second] != 12))   //On ne bouge pas un mur
    {
        if (Grid[PosToMove.first][PosToMove.second] == 11)
        {
            Grid[PosToMove.first][PosToMove.second] = 0;
            DeleteAllNumber (Grid, Grid[Pos.first][Pos.second], Score);
        }
        if (Grid[Pos.first][Pos.second] == 11)
        {
            Grid[Pos.first][Pos.second] = 0;
            DeleteAllNumber (Grid, Grid[PosToMove.first][PosToMove.second], Score);
        }
    swap (Grid[PosToMove.first][PosToMove.second], Grid[Pos.first][Pos.second]);
    }
} //Move ()

void DeleteAllNumber (CMat & Grid, unsigned nbtodelete, unsigned & Score)
{
    unsigned cpt;
    for (unsigned i (0); i < Grid.size(); ++i)
    {
        for (unsigned j(0); j < Grid[i].size(); ++j)
        {
            if (Grid[i][j] == nbtodelete)
            {
                Grid[i][j] = 0;
                cpt++;
            }
        }
    }
    Score += cpt*5;
}

void UpdateGrid (CMat & Grid, CPosition & Pos, unsigned & Score, unsigned NbCandies)
{
    unsigned Howmany;
    do
    {
        while (AtLeastThreeInAColumn (Grid, Pos, Howmany))
        {
            cout << "Une combinaison de " << Howmany << " bonbons a ete trouve dans les colonnes en coordonnées " << Pos.first+1 << " ; " << Pos.second+1  << endl;
            Score += Howmany*5;  //50 points par case détruite

            if (Howmany == 5)
                FiveInColumn (Grid, Pos, Howmany);      //Fait spawn boule spéciale
            if (Howmany != 5)
                RemovalInColumn (Grid, Pos, Howmany);   //REMPLACE PAR DES 0

            DisplayGrid (Grid);
            sleep(1);
            DownGrid (Grid);                            //REMONTE LES 0
        }
        while (AtLeastThreeInARow  (Grid, Pos, Howmany))
        {
            cout << "Une combinaison de " << Howmany << " bonbons a ete trouve dans les lignes en coordonnées " << Pos.first+1 << " ; " << Pos.second+1  << endl;
            Score += Howmany*5; //50 points par case détruite

            if (Howmany == 5)
                FiveInRow (Grid, Pos, Howmany);         //Fait spawn boule spéciale
            if (Howmany != 5)
                RemovalInRow (Grid, Pos, Howmany);      //REMPLACE PAR DES 0

            DisplayGrid (Grid);
            sleep(1);
            DownGrid (Grid);                            //REMONTE LES 0
        }
    }  while (ReplaceEmpty (Grid, NbCandies));
}

unsigned GetUnsigned (unsigned min, unsigned max)
{
    unsigned choix = 0;
    while (true)
    {
        cin >> choix;
        if (cin.fail() || choix > max || choix < min)
        {
            cout << "Valeur incorrecte ("<< min << '-' << max << ')' << endl << endl;
            ClearBuf();
            continue;
        }
        break;
    }
    return choix;
} //GetUnsigned()

CPosition GetPos(CPosition & Pos, unsigned Size)
{
    cout << "Numéro colonne (1 - " << Size << ") : ";
    Pos.second = (GetUnsigned(1,Size) - 1);
    cout << "Numéro ligne (1 - " << Size << ") : ";
    Pos.first = (GetUnsigned(1,Size) - 1);
    return Pos;
} //GetPos()

char GetDirection (char Direction)
{
    while (true)
    {
        cout << "Direction (Haut : "<<MoveUp<<", Gauche : "<<MoveLeft<<", Bas : "<<MoveDown<<", Droite : "<<MoveRight<<") ? ";
        cin >> Direction;
        cout << endl;
        Direction = toupper(Direction);
        if (Direction == MoveUp || Direction == MoveLeft || Direction == MoveDown || Direction == MoveRight) break;
        ClearBuf ();
    }
    return Direction;
} //GetDirection()
