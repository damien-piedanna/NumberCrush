#include <iostream>
#include <iomanip>
#include "gridmanagement.h"

#include "Correc_prof/type.h" //nos types
#include "Correc_prof/params.h" //nos parametres

using namespace std;



void ClearScreen()
{
    cout << "\033[H\033[2J";
}// ClearScreen ()

void Color (const string & Col)
{
    cout << "\033[" << Col.c_str () <<"m";
} // Color ()
