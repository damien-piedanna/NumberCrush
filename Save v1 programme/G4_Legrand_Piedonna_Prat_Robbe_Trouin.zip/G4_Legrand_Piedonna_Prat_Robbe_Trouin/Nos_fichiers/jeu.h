#ifndef JEU_H
#define JEU_H

#include <iostream>
#include <vector>
#include <string>
#include <time.h>
using namespace std;

typedef vector <unsigned> CVLine; // un type représentant une ligne de la grille
typedef vector <CVLine> CMat; // un type représentant la grille
typedef pair <unsigned, unsigned> CPosition; // une position dans la girlle

const string CReset   ("0");

//ATTENTION !!!!!!!!
const unsigned Key(5); // Clé de chiffrement/déchiffrement par César
//AAAAAHHHH !!!!!!!!




void DisplayGrid (const CMat & Grid);                                                   //Affiche la grille
void MakeAMove (CMat & Grid, unsigned & Score);                                         //Donne la possibilité au joueur de faire un move
void Move (CMat & Grid, unsigned & Score, const CPosition & Pos, const CPosition & PosToMove);                          //

void DeleteAllNumber(CMat & Grid, unsigned nbtodelete, unsigned & Score);               //Supprime tout les nbtodelete de la grille
void UpdateGrid (CMat & Grid, CPosition & Pos, unsigned & Score, unsigned NbCandies);  //Mets à jour la grille en cherchant les combinaisons, remontant les 0 et replacer des cases

void ClearAssociation (CMat & Grid, unsigned NbCandies);                               //Supprime les combinaisons de la grille sans ajouter de score
bool ReplaceEmpty (CMat & Grid, unsigned NbCandies);                                   //Remplace les 0 par des nombres aléatoires
void DownGrid (CMat & Grid);                                                            //Fait tomber les cases quand il y a un trou en dessous d'eux

unsigned GetUnsigned (unsigned min, unsigned max);                                      //Recupération d'un unsigned
CPosition GetPos (CPosition & Pos, unsigned Size);                                      //Récupération positions
char GetDirection (char Direction);                                                     //Récupération direction

void PlayGame (CMat & Grid, CPosition Pos, unsigned & Score, unsigned & NbCandies, unsigned & Coup, unsigned &ScoreToWin);  //Lance la partie jusqu'à qu'il n'y ai plus de coups

int jeu();

#endif // JEU_H
