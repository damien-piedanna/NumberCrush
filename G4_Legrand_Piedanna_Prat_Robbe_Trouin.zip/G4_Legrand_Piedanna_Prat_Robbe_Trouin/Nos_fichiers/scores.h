#ifndef SCORES_H
#define SCORES_H

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <vector>

using namespace std;

typedef vector <string> CVString;

void RetrieveData(CVString & VString, const string & FichierSource);

void WriteData(CVString & VString, const string & FichierDest);

unsigned GetScore (CVString & VScores,const unsigned & Ligne);

string GetName(CVString & VScores, const unsigned & Ligne);

void DescendreLignes(CVString & VScores,const unsigned & Ligne);

void AjustementLignes(CVString & VScores);

void ModifScores (CVString & VScores,const unsigned & Score,const string & Name);

void ChiffreCesar(string & Ligne,const unsigned Key);

void DeChiffreCesar(string & Ligne,const unsigned Key);

void DisplayFile2 (const string & File);

void AfficheScores(const unsigned Key, string & File);

void MScores(string & Name, unsigned & Score, const unsigned Key);

string GetStringName(const unsigned & MaxSize);

void SaveScores(unsigned & Score, const unsigned & Key, string & File);

#endif // SCORES_H
