#ifndef MENU_H
#define MENU_H

#include <Nos_fichiers/jeu.h>

void DisplayFile (const string & File);
void Jouer (CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void Classique (CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void Perso(CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void Histoire(CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & NbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void Menu2 (CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & KNbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void RetrieveDataLevel(const string & NameLevel, vector <vector <unsigned>> & Grid, unsigned  & NbCandies, unsigned & Coup, unsigned & ScoreToWin);
void LoadLevel (const string & NameLevel, CMat & Grid, unsigned & NbCandies, unsigned & Coup, unsigned & Size_col, unsigned & Size_lin, unsigned & ScoreToWin);
void RetourMenu (CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & NbCandies, unsigned & Coup, string & LvlScores, unsigned &ScoreToWin);
void MenuScore(CMat & Grid, unsigned & Size_col, unsigned & Size_lin, unsigned & NbCandies, unsigned & Coup, string & LvlScores);

#endif // MENU_H
