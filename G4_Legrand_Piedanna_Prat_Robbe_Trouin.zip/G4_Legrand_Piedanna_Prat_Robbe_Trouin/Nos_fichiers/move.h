#ifndef MOVE_H
#define MOVE_H
#include "jeu.h"
#include "Correc_prof/gridmanagement.h"
#include "gridmanage.h"
#include "consolemanagement.h"
#include <unistd.h>
#include "Nos_fichiers/params2.h"


void ClearAssociation (CMat & Grid, unsigned NbCandies);

bool ReplaceEmpty (CMat & Grid, unsigned NbCandies, bool init);

void DisplayGrid2 (const CMat & Grid);

void DownGrid (CMat & Grid);

void MakeAMove2 (CMat & Grid, unsigned & Score);

void Move (CMat & Grid, unsigned & Score, const CPosition & Pos, const CPosition & PosToMove);

void DeleteAllNumber (CMat & Grid, unsigned nbtodelete, unsigned & Score);

void UpdateGrid (CMat & Grid, CPosition & Pos, unsigned & Score, unsigned NbCandies);

#endif // MOVE_H
