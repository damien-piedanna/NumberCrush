#ifndef PARAMS2_H
#define PARAMS2_H
#include <string>

using namespace std;

void Couleur (const string & coul);

const char MoveUp='Z';
const char MoveDown='S';
const char MoveLeft='Q';
const char MoveRight='D';

void DisplayCouleur(const int & Chiffre);

#endif // PARAMS2_H
