#ifndef CONSOLEMANAGEMENT_H
#define CONSOLEMANAGEMENT_H

#include <Nos_fichiers/jeu.h>

void Couleur (const string & coul);                                                     //Permet d'afficher des couleurs sur la console
void ClearBuf ();                                                                       //Vide le tampon de cin

#endif // CONSOLEMANAGEMENT_H
