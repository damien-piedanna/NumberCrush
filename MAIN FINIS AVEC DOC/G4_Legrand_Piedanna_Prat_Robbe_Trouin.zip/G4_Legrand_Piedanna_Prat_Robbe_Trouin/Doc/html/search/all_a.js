var searchData=
[
  ['main',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['makeamove',['MakeAMove',['../game_8cpp.html#a011f526f9126b19260ea64282764daf7',1,'MakeAMove(CMat &amp;Grid, const CPosition &amp;Pos, char Direction, const CMyParam &amp;Params):&#160;game.cpp'],['../game_8h.html#adf0ee00ccff2b1be0376f5a9c5e9d54d',1,'MakeAMove(CMat &amp;Grid, const CPosition &amp;Pos, char Direction):&#160;game.h']]],
  ['makeamove2',['MakeAMove2',['../move_8cpp.html#a9e11b81772e0c1a43c60154d075ef901',1,'MakeAMove2(CMat &amp;Grid, unsigned &amp;Score):&#160;move.cpp'],['../move_8h.html#a9e11b81772e0c1a43c60154d075ef901',1,'MakeAMove2(CMat &amp;Grid, unsigned &amp;Score):&#160;move.cpp']]],
  ['mapparamchar',['MapParamChar',['../struct_c_my_param.html#ac38ede5a509bd268e749bc9c960466d3',1,'CMyParam']]],
  ['mapparamstring',['MapParamString',['../struct_c_my_param.html#a6f22660b5eff76608f47c52930e6ecf1',1,'CMyParam']]],
  ['mapparamunsigned',['MapParamUnsigned',['../struct_c_my_param.html#aece7d4bdf4103e359f769d08e97a459d',1,'CMyParam']]],
  ['menu',['Menu',['../game_8cpp.html#aa2310e9ab250ce7576dd0e378ca0dd35',1,'Menu(CPosition &amp;Pos, char &amp;Direction, const CMyParam &amp;Params):&#160;game.cpp'],['../game_8h.html#aa2310e9ab250ce7576dd0e378ca0dd35',1,'Menu(CPosition &amp;Pos, char &amp;Direction, const CMyParam &amp;Params):&#160;game.cpp']]],
  ['menu_2ecpp',['menu.cpp',['../menu_8cpp.html',1,'']]],
  ['menu_2eh',['menu.h',['../menu_8h.html',1,'']]],
  ['menu2',['Menu2',['../menu_8cpp.html#a8ada07802305465f73b0426315a84eb6',1,'Menu2(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp'],['../menu_8h.html#a163c51d36d35d55ee3988a6c3fe66d8a',1,'Menu2(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp']]],
  ['menuscore',['MenuScore',['../menu_8cpp.html#a7bb89df2bb71321185e2940ec171b44c',1,'MenuScore(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp'],['../menu_8h.html#ade431b86fe840c0f92cdc2f62f57792e',1,'MenuScore(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores):&#160;menu.h']]],
  ['modifscores',['ModifScores',['../scores_8cpp.html#ae2a68dc2a3a14cb5e8157a03b33dd6bd',1,'ModifScores(CVString &amp;VScores, const unsigned &amp;Score, const string &amp;Name):&#160;scores.cpp'],['../scores_8h.html#ae2a68dc2a3a14cb5e8157a03b33dd6bd',1,'ModifScores(CVString &amp;VScores, const unsigned &amp;Score, const string &amp;Name):&#160;scores.cpp']]],
  ['move',['Move',['../move_8cpp.html#a1c379b3c21d5c72bc32f7149e5647679',1,'Move(CMat &amp;Grid, unsigned &amp;Score, const CPosition &amp;Pos, const CPosition &amp;PosToMove):&#160;move.cpp'],['../move_8h.html#a1c379b3c21d5c72bc32f7149e5647679',1,'Move(CMat &amp;Grid, unsigned &amp;Score, const CPosition &amp;Pos, const CPosition &amp;PosToMove):&#160;move.cpp']]],
  ['move_2ecpp',['move.cpp',['../move_8cpp.html',1,'']]],
  ['move_2eh',['move.h',['../move_8h.html',1,'']]],
  ['movedown',['MoveDown',['../params2_8h.html#aa828d5b083013d19e8c00d2bed95613c',1,'params2.h']]],
  ['moveleft',['MoveLeft',['../params2_8h.html#ae130968a3e0f1c98d17fa68781d14234',1,'params2.h']]],
  ['moveright',['MoveRight',['../params2_8h.html#a2f0364f4fee80aac6a166d92123b41a5',1,'params2.h']]],
  ['moveup',['MoveUp',['../params2_8h.html#ad4888271d5f916a1368a7d1676b74566',1,'params2.h']]],
  ['mscores',['MScores',['../scores_8cpp.html#a04cf257357e5c58911014b6e83504ab1',1,'MScores(string &amp;Name, unsigned &amp;Score, const unsigned Key, string &amp;File):&#160;scores.cpp'],['../scores_8h.html#a48a8e8522fdfdb5605c67374b66a9b6b',1,'MScores(string &amp;Name, unsigned &amp;Score, const unsigned Key):&#160;scores.h']]]
];
