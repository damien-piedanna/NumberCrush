var searchData=
[
  ['params_2ecpp',['params.cpp',['../params_8cpp.html',1,'']]],
  ['params_2eh',['params.h',['../params_8h.html',1,'']]],
  ['params2_2ecpp',['params2.cpp',['../params2_8cpp.html',1,'']]],
  ['params2_2eh',['params2.h',['../params2_8h.html',1,'']]],
  ['partieperso',['PartiePerso',['../menu_8cpp.html#a46c68463f0090ea6f6ecec0ed4aadff6',1,'PartiePerso(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup):&#160;menu.cpp'],['../menu_8h.html#a46c68463f0090ea6f6ecec0ed4aadff6',1,'PartiePerso(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup):&#160;menu.cpp']]],
  ['pause',['Pause',['../consolemanagement_8cpp.html#aec72643c810ddc3303da38c65ba79744',1,'Pause(float secondes):&#160;consolemanagement.cpp'],['../consolemanagement_8h.html#aec72643c810ddc3303da38c65ba79744',1,'Pause(float secondes):&#160;consolemanagement.cpp']]],
  ['perso',['Perso',['../menu_8cpp.html#ae6d5455e3446f04945a3a88489ffa95a',1,'Perso(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp'],['../menu_8h.html#ae6d5455e3446f04945a3a88489ffa95a',1,'Perso(CMat &amp;Grid, unsigned &amp;Size_col, unsigned &amp;Size_lin, unsigned &amp;NbCandies, unsigned &amp;Coup, string &amp;LvlScores, unsigned &amp;ScoreToWin):&#160;menu.cpp']]],
  ['playgame',['PlayGame',['../jeu_8cpp.html#a65774287a4de0b6ca018fdca2cbdcc74',1,'PlayGame(CMat &amp;Grid, CPosition Pos, unsigned &amp;Score, unsigned &amp;NbCandies, unsigned &amp;Coup, unsigned &amp;ScoreToWin):&#160;jeu.cpp'],['../jeu_8h.html#a65774287a4de0b6ca018fdca2cbdcc74',1,'PlayGame(CMat &amp;Grid, CPosition Pos, unsigned &amp;Score, unsigned &amp;NbCandies, unsigned &amp;Coup, unsigned &amp;ScoreToWin):&#160;jeu.cpp']]],
  ['ppal',['ppal',['../game_8cpp.html#a0b1d64ee76933ef8f007f1208cb869a7',1,'ppal():&#160;game.cpp'],['../game_8h.html#a0b1d64ee76933ef8f007f1208cb869a7',1,'ppal():&#160;game.cpp']]]
];
